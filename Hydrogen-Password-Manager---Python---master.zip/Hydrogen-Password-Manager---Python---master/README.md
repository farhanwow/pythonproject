# Hydrogen Password Manager [ Python ]
 >> Hydrogen GUI Password Manager

 - A Simple And Secure Way To Manage All Your Important Credentials At One Place.

[Image1](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/2.png)

![Image2](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/2.png)

![Image3](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/3.png)

![Image4](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/4.png)

![Image5](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/5.png)

![Image6](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/6.png)

![Image7](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/7.png)

![Image8](https://raw.githubusercontent.com/tanmay606/Hydrogen-Password-Manager---Python--/master/Images/8.png)



This Password Manager Program Will Let You Relax As Now All You Have To Remember Is Hydrogen (Master ID And Password) To Access And Manage
 All Your Credentials In Secure Way.

 (ie. now i can store facebook Gmail twitter and many more account credentials at one place to avoid forgetting it.)

Features : 

1. Strong Symmetric Based Encryption For :
    a. Master Account ie. (Password Manager Main Credentials)

    		It is required to access the main vault which holds all the credentials.

    b. For Credentials Of every Saved Account Under Vault.

    	I Know Your Privacy Is Important, Hence In Hydrogen Your Every Credential Will Be Stored In Encrypted Database.
    	It Will Be Unlocked Only When You Have Master Acess To The Program.


Resources : 

2. Used 
	Pyqt : For GUI Implementation
	Sqlite : For Database Based Operations
	Cryptography : To Provide Security To Credentials
	Some BuiltIn Libs For Basic Program Operations.



3. Any Bugs / Absence Of Feature In This Version (Soon To Be Fixed In Next Version)
  
   1. Recovery Of Master Password Is Not Supported Till Now.
   2. Code Is Currently Not Quite UserFriendly.
   3. Need To Work On More Efficiency And Security.
   4. Due To Implementation Of Database Encryption Mechanism Avoid Closing Program Indirectly. (SOLVED)

   (I Will Appreciate Your Feedbacks, Criticism,Suggestions etc. )


4. Usage :
	
		It's Very Simple To Use This Program, I Will Also Attach A Youtube Video With This For More Ease.



[IMP]Please Ensure To Install Below Requisite Modules Before Using This To Avoid Import Error :

 1. Cryptography
 2. PyQt5


(If black window annoys you , just change .py extention with .pyw )


You can also make executable (.exe ) file using pyinstaller which will help you to make this program portable to other machines.