# __init__.py
from .MBisection import hitung as MB
from .RegulaFalsi import hitung as RF
from .NewtonRaphson import hitung as NR
from .myfunc import * 
