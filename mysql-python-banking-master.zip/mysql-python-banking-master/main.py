import wx, program

if __name__ == "__main__":
    app = wx.App()
    frame = program.Program()
    frame.Show()
    app.MainLoop()